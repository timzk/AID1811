#test_import.py
#此示例示意用visual studio　code在用
# contrl + 鼠标左键点击时可以跳转到源码

import copy
import mypack.games.contra