
def show_menu():
    print('1)魂斗罗MU')
    print('2)超级玛丽')
    print('3)坦克大战')
    print('4)word')
    print('5)excel')

print('mypack/menu模块被加载!!!')
