#mypack/games/__init__.py
#此列表限定用在
#from mypack.game import *
#语句导入时,会导入contra 和tanks模块
__all__ = ['contra','tanks']