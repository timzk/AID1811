import sys
#接收命令行输入,作为值
print(sys.argv)