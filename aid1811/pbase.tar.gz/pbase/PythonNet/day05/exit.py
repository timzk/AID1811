#退出进程示例
import os
import sys
# os._exit(0)
sys.exit("进程退出")
#不会打印以下内容
print("ABC")