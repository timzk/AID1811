s=int(input('输入一段字符串:'))
print (' ' * s +'d' )
print(' '*(s-1)+'ddd')
print(' '*(s-2)+'ddddd')
print(' '*(s-3)+'dddddddd')

a=' jdnj fj'
print(a.replace(' ',''))

# a=input("请输入第一行：")
# b=input("请输入第二行：")
# c=input("请输入第三行：")
# max_len= max(len(a),len(b),len(c))
# print("最长的个数"max_len)

