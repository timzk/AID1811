'''
    这是一个自定义模块mymod

    上面是标题
'''
def myfac(n):
      print("正在计算",n,"的阶乘")
def mysum(n):
    print("正在计算1+2+3...+%d的和" % n)

  
name1 = "audi"
name2 = "TESLA"
print("mymod 模块被加载")
print("mymod.__name__值为:",__name__)

