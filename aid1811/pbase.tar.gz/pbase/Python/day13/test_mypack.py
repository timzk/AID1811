#test_mypack.py
import mypack.games.contra as contra

contra.play()

contra.gameover()
