import sys

sys.stdout.write("hello world")
sys.stderr.write("出现是个错误")