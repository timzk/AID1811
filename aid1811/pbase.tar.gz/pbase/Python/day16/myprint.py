import sys
 def myprint(*args,sep= ' ',end='\n',file = sys.stdout,flush = False):
     