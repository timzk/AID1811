#mypack/__init__.py
'''
这是mypack包的标题

此包有两个子包:
    games和office
此包有一个模块
    menu.py
'''

def test_mypack():
    print('__init__.py里的test_mypack,被调用!')
    