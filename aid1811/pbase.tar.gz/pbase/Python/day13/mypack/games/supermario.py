#file:mypack/games/contar.py

def play():
    print('正在玩　超级玛丽...')

print('超集玛丽被加载!!')


